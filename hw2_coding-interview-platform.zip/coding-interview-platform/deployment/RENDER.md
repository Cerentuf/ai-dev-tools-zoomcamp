# Render Deployment Configuration

## Prerequisites
- Render account (https://render.com)
- GitHub repository

## Deployment Steps

1. **Push code to GitHub**
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin <your-github-repo-url>
git push -u origin main
```

2. **Create New Web Service on Render**
- Go to https://render.com/dashboard
- Click "New +" → "Web Service"
- Connect your GitHub repository
- Configure:
  - **Name**: coding-interview-platform
  - **Environment**: Docker
  - **Plan**: Free
  - **Docker Command**: (leave empty, uses Dockerfile CMD)

3. **Deploy**
- Render will automatically deploy from your Dockerfile
- It will build and start your application

4. **Access Your App**
- Your app will be available at: `https://your-app-name.onrender.com`

## Using render.yaml (Infrastructure as Code)

You can also use the `render.yaml` file in the root directory:

```bash
# The render.yaml file is already configured
# Just connect your repo and Render will use it automatically
```

## Environment Variables
Set in Render Dashboard:
- `NODE_ENV=production`
- `PORT=3001` (or let Render assign)

## Features
- ✅ Free tier available
- ✅ Automatic HTTPS
- ✅ Auto-deploy on git push
- ✅ Docker support
- ✅ WebSocket support
