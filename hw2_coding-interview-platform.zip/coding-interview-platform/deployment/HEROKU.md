# Heroku Deployment Configuration

## Prerequisites
- Heroku account
- Heroku CLI installed

## Deployment Steps

1. **Login to Heroku**
```bash
heroku login
```

2. **Create a new Heroku app**
```bash
heroku create your-app-name
```

3. **Set buildpacks**
```bash
heroku buildpacks:set heroku/nodejs
```

4. **Deploy**
```bash
git push heroku main
```

5. **Open the app**
```bash
heroku open
```

## Environment Variables
```bash
heroku config:set NODE_ENV=production
```

## Scale
```bash
heroku ps:scale web=1
```
