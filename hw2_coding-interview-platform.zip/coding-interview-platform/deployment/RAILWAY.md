# Railway Deployment Configuration

## Prerequisites
- Railway account (https://railway.app)
- GitHub repository

## Deployment Steps

1. **Push code to GitHub**
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin <your-github-repo-url>
git push -u origin main
```

2. **Deploy on Railway**
- Go to https://railway.app
- Click "New Project"
- Select "Deploy from GitHub repo"
- Choose your repository
- Railway will auto-detect the Dockerfile and deploy

3. **Configure**
- Railway automatically detects and uses your Dockerfile
- No additional configuration needed!

4. **Access Your App**
- Railway provides a URL: `https://your-app.railway.app`

## Alternative: Using Railway CLI

```bash
# Install Railway CLI
npm install -g @railway/cli

# Login
railway login

# Initialize project
railway init

# Deploy
railway up
```

## Environment Variables
```bash
railway variables set NODE_ENV=production
```

## Features
- ✅ Free tier with $5 monthly credit
- ✅ Automatic HTTPS
- ✅ Auto-deploy on git push
- ✅ Docker support
- ✅ WebSocket support
- ✅ Simple CLI
