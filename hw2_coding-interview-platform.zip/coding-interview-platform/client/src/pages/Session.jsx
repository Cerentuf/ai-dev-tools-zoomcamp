import { useState, useEffect, useRef } from 'react';
import { useParams } from 'react-router-dom';
import Editor from '@monaco-editor/react';
import io from 'socket.io-client';
import { loadPyodide } from 'pyodide';
import './Session.css';

function Session() {
  const { sessionId } = useParams();
  const [code, setCode] = useState('// Start coding here...');
  const [language, setLanguage] = useState('javascript');
  const [userCount, setUserCount] = useState(1);
  const [output, setOutput] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const socketRef = useRef(null);
  const isRemoteChange = useRef(false);
  const pyodideRef = useRef(null);

  useEffect(() => {
    // Connect to socket
    socketRef.current = io('http://localhost:3001');

    socketRef.current.emit('join-session', sessionId);

    // Listen for code updates from other users
    socketRef.current.on('code-update', ({ code: newCode, language: newLanguage }) => {
      isRemoteChange.current = true;
      setCode(newCode);
      setLanguage(newLanguage);
    });

    socketRef.current.on('language-update', ({ language: newLanguage }) => {
      setLanguage(newLanguage);
    });

    socketRef.current.on('user-joined', ({ userCount: count }) => {
      setUserCount(count);
    });

    socketRef.current.on('user-left', ({ userCount: count }) => {
      setUserCount(count);
    });

    // Copy session link
    const url = window.location.href;
    console.log('Session URL:', url);

    return () => {
      if (socketRef.current) {
        socketRef.current.disconnect();
      }
    };
  }, [sessionId]);

  const handleCodeChange = (value) => {
    setCode(value);
    
    if (!isRemoteChange.current && socketRef.current) {
      socketRef.current.emit('code-change', {
        sessionId,
        code: value,
        language
      });
    }
    isRemoteChange.current = false;
  };

  const handleLanguageChange = (e) => {
    const newLanguage = e.target.value;
    setLanguage(newLanguage);
    
    if (socketRef.current) {
      socketRef.current.emit('language-change', {
        sessionId,
        language: newLanguage
      });
    }

    // Set default code for language
    if (newLanguage === 'python') {
      const defaultPython = '# Start coding here...\nprint("Hello, World!")';
      setCode(defaultPython);
      handleCodeChange(defaultPython);
    } else {
      const defaultJS = '// Start coding here...\nconsole.log("Hello, World!");';
      setCode(defaultJS);
      handleCodeChange(defaultJS);
    }
  };

  const copySessionLink = () => {
    navigator.clipboard.writeText(window.location.href);
    alert('Session link copied to clipboard!');
  };

  const runCode = async () => {
    setIsRunning(true);
    setOutput('Running...');

    try {
      if (language === 'javascript') {
        // Execute JavaScript code
        const logs = [];
        const originalLog = console.log;
        const originalError = console.error;

        // Capture console output
        console.log = (...args) => {
          logs.push(args.map(arg => String(arg)).join(' '));
        };
        console.error = (...args) => {
          logs.push('ERROR: ' + args.map(arg => String(arg)).join(' '));
        };

        try {
          // eslint-disable-next-line no-eval
          eval(code);
          setOutput(logs.join('\n') || 'Code executed successfully (no output)');
        } catch (error) {
          setOutput(`Error: ${error.message}`);
        } finally {
          console.log = originalLog;
          console.error = originalError;
        }
      } else if (language === 'python') {
        // Execute Python code using Pyodide (WASM)
        if (!pyodideRef.current) {
          setOutput('Loading Python environment...');
          pyodideRef.current = await loadPyodide({
            indexURL: 'https://cdn.jsdelivr.net/pyodide/v0.24.1/full/'
          });
        }

        const pyodide = pyodideRef.current;

        // Redirect stdout
        await pyodide.runPythonAsync(`
          import sys
          from io import StringIO
          sys.stdout = StringIO()
          sys.stderr = StringIO()
        `);

        try {
          await pyodide.runPythonAsync(code);
          const stdout = await pyodide.runPythonAsync('sys.stdout.getvalue()');
          const stderr = await pyodide.runPythonAsync('sys.stderr.getvalue()');
          
          let result = '';
          if (stdout) result += stdout;
          if (stderr) result += '\nERROR: ' + stderr;
          
          setOutput(result || 'Code executed successfully (no output)');
        } catch (error) {
          setOutput(`Error: ${error.message}`);
        }
      }
    } catch (error) {
      setOutput(`Execution error: ${error.message}`);
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <div className="session">
      <div className="header">
        <div className="header-left">
          <h2>Coding Interview Session</h2>
          <span className="user-count">👥 {userCount} user(s) connected</span>
        </div>
        <div className="header-right">
          <select value={language} onChange={handleLanguageChange} className="language-select">
            <option value="javascript">JavaScript</option>
            <option value="python">Python</option>
          </select>
          <button onClick={copySessionLink} className="btn-secondary">
            📋 Copy Link
          </button>
          <button onClick={runCode} className="btn-primary" disabled={isRunning}>
            {isRunning ? '⏳ Running...' : '▶ Run Code'}
          </button>
        </div>
      </div>
      
      <div className="editor-container">
        <Editor
          height="100%"
          language={language}
          value={code}
          onChange={handleCodeChange}
          theme="vs-dark"
          options={{
            minimap: { enabled: false },
            fontSize: 14,
            wordWrap: 'on',
            automaticLayout: true,
          }}
        />
      </div>

      {output && (
        <div className="output-container">
          <h3>Output:</h3>
          <pre>{output}</pre>
        </div>
      )}
    </div>
  );
}

export default Session;
