import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Home.css';

function Home() {
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const createSession = async () => {
    setLoading(true);
    try {
      const response = await fetch('http://localhost:3001/api/session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      const data = await response.json();
      navigate(`/session/${data.sessionId}`);
    } catch (error) {
      console.error('Error creating session:', error);
      alert('Failed to create session');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="home">
      <div className="home-container">
        <h1>Coding Interview Platform</h1>
        <p>Create a collaborative coding session and share it with candidates</p>
        <button 
          className="create-btn" 
          onClick={createSession}
          disabled={loading}
        >
          {loading ? 'Creating...' : 'Create New Session'}
        </button>
      </div>
    </div>
  );
}

export default Home;
