import { useState, useEffect, useRef } from 'react';
import { useParams } from 'react-router-dom';
import Editor from '@monaco-editor/react';
import io from 'socket.io-client';
import './CodeEditor.css';

const SOCKET_URL = 'http://localhost:3001';

function CodeEditor() {
  const { sessionId } = useParams();
  const [code, setCode] = useState('// Loading...');
  const [language, setLanguage] = useState('javascript');
  const [output, setOutput] = useState('');
  const [users, setUsers] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const socketRef = useRef(null);
  const editorRef = useRef(null);
  const pyodideRef = useRef(null);

  useEffect(() => {
    // Initialize socket connection
    socketRef.current = io(SOCKET_URL);

    // Join the session
    socketRef.current.emit('join-session', sessionId);

    // Listen for initial code
    socketRef.current.on('initial-code', ({ code: initialCode, language: initialLanguage }) => {
      setCode(initialCode);
      setLanguage(initialLanguage);
    });

    // Listen for code updates from other users
    socketRef.current.on('code-update', (newCode) => {
      setCode(newCode);
    });

    // Listen for language updates
    socketRef.current.on('language-update', (newLanguage) => {
      setLanguage(newLanguage);
    });

    // Listen for user count updates
    socketRef.current.on('user-count', (count) => {
      setUsers(count);
    });

    // Listen for errors
    socketRef.current.on('error', ({ message }) => {
      alert(message);
    });

    // Cleanup on unmount
    return () => {
      if (socketRef.current) {
        socketRef.current.disconnect();
      }
    };
  }, [sessionId]);

  // Load Pyodide for Python execution
  useEffect(() => {
    if (language === 'python' && !pyodideRef.current) {
      loadPyodide();
    }
  }, [language]);

  const loadPyodide = async () => {
    try {
      const pyodide = await window.loadPyodide({
        indexURL: 'https://cdn.jsdelivr.net/pyodide/v0.23.4/full/'
      });
      pyodideRef.current = pyodide;
      console.log('Pyodide loaded successfully');
    } catch (error) {
      console.error('Error loading Pyodide:', error);
    }
  };

  const handleEditorChange = (value) => {
    setCode(value);
    if (socketRef.current) {
      socketRef.current.emit('code-change', { sessionId, code: value });
    }
  };

  const handleLanguageChange = (e) => {
    const newLanguage = e.target.value;
    setLanguage(newLanguage);
    if (socketRef.current) {
      socketRef.current.emit('language-change', { sessionId, language: newLanguage });
    }
  };

  const runCode = async () => {
    setIsRunning(true);
    setOutput('Running...');

    try {
      if (language === 'javascript') {
        // Run JavaScript code
        const logs = [];
        const originalLog = console.log;
        console.log = (...args) => {
          logs.push(args.join(' '));
        };

        try {
          // eslint-disable-next-line no-eval
          eval(code);
          setOutput(logs.join('\n') || 'Code executed successfully (no output)');
        } catch (error) {
          setOutput(`Error: ${error.message}`);
        } finally {
          console.log = originalLog;
        }
      } else if (language === 'python') {
        // Run Python code using Pyodide
        if (!pyodideRef.current) {
          setOutput('Loading Python runtime...');
          await loadPyodide();
        }

        try {
          // Redirect stdout
          pyodideRef.current.runPython(`
            import sys
            from io import StringIO
            sys.stdout = StringIO()
          `);

          // Run the user's code
          await pyodideRef.current.runPythonAsync(code);

          // Get the output
          const stdout = pyodideRef.current.runPython('sys.stdout.getvalue()');
          setOutput(stdout || 'Code executed successfully (no output)');
        } catch (error) {
          setOutput(`Error: ${error.message}`);
        }
      }
    } catch (error) {
      setOutput(`Error: ${error.message}`);
    } finally {
      setIsRunning(false);
    }
  };

  const copySessionLink = () => {
    const link = window.location.href;
    navigator.clipboard.writeText(link);
    alert('Session link copied to clipboard!');
  };

  return (
    <div className="editor-container">
      <div className="header">
        <div className="header-left">
          <h2>Coding Interview Session</h2>
          <span className="user-count">👥 {users} user{users !== 1 ? 's' : ''} connected</span>
        </div>
        <div className="header-right">
          <select value={language} onChange={handleLanguageChange} className="language-select">
            <option value="javascript">JavaScript</option>
            <option value="python">Python</option>
          </select>
          <button onClick={copySessionLink} className="btn btn-secondary">
            📋 Copy Link
          </button>
          <button onClick={runCode} disabled={isRunning} className="btn btn-primary">
            ▶️ Run Code
          </button>
        </div>
      </div>

      <div className="content">
        <div className="editor-panel">
          <Editor
            height="100%"
            language={language}
            value={code}
            onChange={handleEditorChange}
            theme="vs-dark"
            options={{
              minimap: { enabled: false },
              fontSize: 14,
              lineNumbers: 'on',
              roundedSelection: false,
              scrollBeyondLastLine: false,
              automaticLayout: true,
            }}
            onMount={(editor) => {
              editorRef.current = editor;
            }}
          />
        </div>

        <div className="output-panel">
          <div className="output-header">Output</div>
          <pre className="output-content">{output || 'Run your code to see the output...'}</pre>
        </div>
      </div>
    </div>
  );
}

export default CodeEditor;
