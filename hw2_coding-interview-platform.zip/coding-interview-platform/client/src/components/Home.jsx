import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Home.css';

const API_URL = 'http://localhost:3001';

function Home() {
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const createSession = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_URL}/api/sessions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      const data = await response.json();
      navigate(`/session/${data.sessionId}`);
    } catch (error) {
      console.error('Error creating session:', error);
      alert('Failed to create session. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="home">
      <div className="home-container">
        <h1>Coding Interview Platform</h1>
        <p className="subtitle">Real-time collaborative coding environment</p>
        
        <div className="features">
          <div className="feature">
            <span className="icon">👥</span>
            <span>Real-time collaboration</span>
          </div>
          <div className="feature">
            <span className="icon">💻</span>
            <span>Syntax highlighting</span>
          </div>
          <div className="feature">
            <span className="icon">▶️</span>
            <span>Code execution</span>
          </div>
        </div>

        <button 
          className="create-btn" 
          onClick={createSession}
          disabled={loading}
        >
          {loading ? 'Creating...' : 'Create New Interview Session'}
        </button>
      </div>
    </div>
  );
}

export default Home;
