const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "http://localhost:5173",
    methods: ["GET", "POST"]
  }
});

app.use(cors());
app.use(express.json());

// Store active sessions
const sessions = new Map();

// Create a new session
app.post('/api/session', (req, res) => {
  const sessionId = uuidv4();
  sessions.set(sessionId, {
    id: sessionId,
    code: '',
    language: 'javascript',
    users: []
  });
  res.json({ sessionId });
});

// Get session info
app.get('/api/session/:id', (req, res) => {
  const session = sessions.get(req.params.id);
  if (session) {
    res.json(session);
  } else {
    res.status(404).json({ error: 'Session not found' });
  }
});

// Socket.IO connection handling
io.on('connection', (socket) => {
  console.log('New client connected:', socket.id);

  socket.on('join-session', (sessionId) => {
    const session = sessions.get(sessionId);
    if (session) {
      socket.join(sessionId);
      session.users.push(socket.id);
      
      // Send current code to the new user
      socket.emit('code-update', {
        code: session.code,
        language: session.language
      });
      
      // Notify others about new user
      socket.to(sessionId).emit('user-joined', {
        userId: socket.id,
        userCount: session.users.length
      });
      
      console.log(`User ${socket.id} joined session ${sessionId}`);
    } else {
      socket.emit('error', { message: 'Session not found' });
    }
  });

  socket.on('code-change', ({ sessionId, code, language }) => {
    const session = sessions.get(sessionId);
    if (session) {
      session.code = code;
      session.language = language;
      
      // Broadcast to all users in the session except sender
      socket.to(sessionId).emit('code-update', { code, language });
    }
  });

  socket.on('language-change', ({ sessionId, language }) => {
    const session = sessions.get(sessionId);
    if (session) {
      session.language = language;
      socket.to(sessionId).emit('language-update', { language });
    }
  });

  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id);
    
    // Remove user from all sessions
    sessions.forEach((session, sessionId) => {
      const index = session.users.indexOf(socket.id);
      if (index !== -1) {
        session.users.splice(index, 1);
        io.to(sessionId).emit('user-left', {
          userId: socket.id,
          userCount: session.users.length
        });
      }
    });
  });
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
