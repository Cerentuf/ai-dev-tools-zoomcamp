const request = require('supertest');
const { io: Client } = require('socket.io-client');
const { app, server, io } = require('./server');

let clientSocket;

describe('Coding Interview Platform API', () => {
  afterAll((done) => {
    server.close(done);
  });

  afterEach(() => {
    if (clientSocket && clientSocket.connected) {
      clientSocket.disconnect();
    }
  });

  describe('POST /api/sessions', () => {
    it('should create a new session and return sessionId', async () => {
      const response = await request(app)
        .post('/api/sessions')
        .expect(200);

      expect(response.body).toHaveProperty('sessionId');
      expect(typeof response.body.sessionId).toBe('string');
      expect(response.body.sessionId.length).toBeGreaterThan(0);
    });
  });

  describe('GET /api/sessions/:sessionId', () => {
    it('should return session info for existing session', async () => {
      // First create a session
      const createResponse = await request(app)
        .post('/api/sessions')
        .expect(200);

      const { sessionId } = createResponse.body;

      // Then get the session info
      const getResponse = await request(app)
        .get(`/api/sessions/${sessionId}`)
        .expect(200);

      expect(getResponse.body).toHaveProperty('id', sessionId);
      expect(getResponse.body).toHaveProperty('code');
      expect(getResponse.body).toHaveProperty('language', 'javascript');
      expect(getResponse.body).toHaveProperty('users', 0);
    });

    it('should return 404 for non-existent session', async () => {
      const response = await request(app)
        .get('/api/sessions/non-existent-id')
        .expect(404);

      expect(response.body).toHaveProperty('error', 'Session not found');
    });
  });
});

describe('WebSocket Integration Tests', () => {
  let sessionId;

  beforeAll(async () => {
    // Create a session for WebSocket tests
    const response = await request(app)
      .post('/api/sessions')
      .expect(200);
    sessionId = response.body.sessionId;
  });

  afterAll((done) => {
    server.close(done);
  });

  afterEach(() => {
    if (clientSocket && clientSocket.connected) {
      clientSocket.disconnect();
    }
  });

  it('should connect and join a session', (done) => {
    clientSocket = Client('http://localhost:3001');

    clientSocket.on('connect', () => {
      clientSocket.emit('join-session', sessionId);
    });

    clientSocket.on('initial-code', (data) => {
      expect(data).toHaveProperty('code');
      expect(data).toHaveProperty('language', 'javascript');
      done();
    });
  });

  it('should receive user count update when joining', (done) => {
    clientSocket = Client('http://localhost:3001');

    clientSocket.on('connect', () => {
      clientSocket.emit('join-session', sessionId);
    });

    clientSocket.on('user-count', (count) => {
      expect(typeof count).toBe('number');
      expect(count).toBeGreaterThan(0);
      done();
    });
  });

  it('should broadcast code changes to other users', (done) => {
    const client1 = Client('http://localhost:3001');
    const client2 = Client('http://localhost:3001');

    let client1Ready = false;
    let client2Ready = false;

    client1.on('connect', () => {
      client1.emit('join-session', sessionId);
    });

    client2.on('connect', () => {
      client2.emit('join-session', sessionId);
    });

    client1.on('initial-code', () => {
      client1Ready = true;
      checkBothReady();
    });

    client2.on('initial-code', () => {
      client2Ready = true;
      checkBothReady();
    });

    function checkBothReady() {
      if (client1Ready && client2Ready) {
        const testCode = 'console.log("test");';
        client1.emit('code-change', { sessionId, code: testCode });
      }
    }

    client2.on('code-update', (code) => {
      expect(code).toBe('console.log("test");');
      client1.disconnect();
      client2.disconnect();
      done();
    });
  });

  it('should broadcast language changes to all users', (done) => {
    const client1 = Client('http://localhost:3001');
    const client2 = Client('http://localhost:3001');

    let client1Ready = false;
    let client2Ready = false;

    client1.on('connect', () => {
      client1.emit('join-session', sessionId);
    });

    client2.on('connect', () => {
      client2.emit('join-session', sessionId);
    });

    client1.on('initial-code', () => {
      client1Ready = true;
      checkBothReady();
    });

    client2.on('initial-code', () => {
      client2Ready = true;
      checkBothReady();
    });

    function checkBothReady() {
      if (client1Ready && client2Ready) {
        client1.emit('language-change', { sessionId, language: 'python' });
      }
    }

    client2.on('language-update', (language) => {
      expect(language).toBe('python');
      client1.disconnect();
      client2.disconnect();
      done();
    });
  });

  it('should handle non-existent session gracefully', (done) => {
    clientSocket = Client('http://localhost:3001');

    clientSocket.on('connect', () => {
      clientSocket.emit('join-session', 'non-existent-session-id');
    });

    clientSocket.on('error', (data) => {
      expect(data).toHaveProperty('message', 'Session not found');
      done();
    });
  });
});
