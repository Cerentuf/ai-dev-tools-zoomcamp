module.exports = {
  testEnvironment: 'node',
  testTimeout: 10000,
  verbose: true
};
