const request = require('supertest');
const io = require('socket.io-client');

const SERVER_URL = 'http://localhost:3001';

describe('Coding Interview Platform Integration Tests', () => {
  let sessionId;

  describe('Session API', () => {
    test('should create a new session', async () => {
      const response = await request(SERVER_URL)
        .post('/api/session')
        .expect(200);

      expect(response.body).toHaveProperty('sessionId');
      expect(typeof response.body.sessionId).toBe('string');
      sessionId = response.body.sessionId;
    });

    test('should retrieve session information', async () => {
      const response = await request(SERVER_URL)
        .get(`/api/session/${sessionId}`)
        .expect(200);

      expect(response.body).toHaveProperty('id', sessionId);
      expect(response.body).toHaveProperty('code');
      expect(response.body).toHaveProperty('language');
      expect(response.body).toHaveProperty('users');
    });

    test('should return 404 for non-existent session', async () => {
      await request(SERVER_URL)
        .get('/api/session/non-existent-id')
        .expect(404);
    });
  });

  describe('WebSocket Communication', () => {
    let socket1, socket2;

    beforeEach((done) => {
      socket1 = io(SERVER_URL);
      socket2 = io(SERVER_URL);
      
      let connectedCount = 0;
      const checkConnected = () => {
        connectedCount++;
        if (connectedCount === 2) done();
      };

      socket1.on('connect', checkConnected);
      socket2.on('connect', checkConnected);
    });

    afterEach(() => {
      if (socket1) socket1.disconnect();
      if (socket2) socket2.disconnect();
    });

    test('should allow users to join a session', (done) => {
      socket1.emit('join-session', sessionId);
      
      socket1.on('code-update', (data) => {
        expect(data).toHaveProperty('code');
        expect(data).toHaveProperty('language');
        done();
      });
    });

    test('should broadcast code changes to other users', (done) => {
      const testCode = 'console.log("test");';
      
      socket1.emit('join-session', sessionId);
      socket2.emit('join-session', sessionId);

      socket2.on('code-update', (data) => {
        if (data.code === testCode) {
          expect(data.code).toBe(testCode);
          expect(data.language).toBe('javascript');
          done();
        }
      });

      setTimeout(() => {
        socket1.emit('code-change', {
          sessionId,
          code: testCode,
          language: 'javascript'
        });
      }, 100);
    });

    test('should broadcast language changes', (done) => {
      socket1.emit('join-session', sessionId);
      socket2.emit('join-session', sessionId);

      socket2.on('language-update', (data) => {
        expect(data.language).toBe('python');
        done();
      });

      setTimeout(() => {
        socket1.emit('language-change', {
          sessionId,
          language: 'python'
        });
      }, 100);
    });

    test('should notify when users join', (done) => {
      socket1.emit('join-session', sessionId);

      socket1.on('user-joined', (data) => {
        expect(data).toHaveProperty('userId');
        expect(data).toHaveProperty('userCount');
        expect(data.userCount).toBeGreaterThan(0);
        done();
      });

      setTimeout(() => {
        socket2.emit('join-session', sessionId);
      }, 100);
    });
  });
});
