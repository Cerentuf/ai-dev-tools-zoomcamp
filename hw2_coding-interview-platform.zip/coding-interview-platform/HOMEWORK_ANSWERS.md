# Homework Answers - Coding Interview Platform

## Question 1: Initial Implementation Prompt

**The prompt I gave to AI to start the implementation:**

```
Create a real-time collaborative coding interview platform with the following requirements:

FRONTEND (React + Vite):
- A home page where users can create a new interview session
- A session page with a code editor that supports real-time collaboration
- Integration with Socket.IO for real-time updates
- Support for sharing session links
- Monaco Editor for code editing with syntax highlighting

BACKEND (Express.js + Socket.IO):
- REST API endpoint to create new sessions (POST /api/session)
- REST API endpoint to get session info (GET /api/session/:id)
- WebSocket server for real-time communication
- Handle multiple users joining the same session
- Broadcast code changes to all connected users
- Track connected users per session

FEATURES:
- Create shareable session links with unique IDs
- Real-time code synchronization between all users
- Support for multiple programming languages (JavaScript, Python)
- User count display
- Clean, modern UI

Use:
- Frontend: React 18 + Vite + Monaco Editor + Socket.IO Client
- Backend: Express.js + Socket.IO + UUID for session IDs
- Real-time communication via WebSockets
```

---

## Question 2: Integration Tests

**Terminal command to execute tests:**

```bash
npm test
```

Or if you're in the tests directory:
```bash
cd tests
npm test
```

The tests check:
- ✅ Session creation API
- ✅ Session retrieval API
- ✅ WebSocket connection
- ✅ Real-time code synchronization
- ✅ Language change broadcasting
- ✅ User join/leave notifications

---

## Question 3: Running Both Client and Server

**Command in root package.json for `npm dev`:**

```json
"dev": "concurrently \"cd server && npm run dev\" \"cd client && npm run dev\""
```

This uses the `concurrently` package to run both the server (on port 3001) and client (on port 5173) simultaneously.

To run:
```bash
npm install  # Install concurrently first
npm run dev  # Start both server and client
```

---

## Question 4: Syntax Highlighting Library

**Library used for syntax highlighting:**

**Monaco Editor** (`@monaco-editor/react` version 4.6.0)

Monaco Editor is the same editor that powers VS Code. It provides:
- Built-in syntax highlighting for JavaScript, Python, and 50+ languages
- IntelliSense and auto-completion
- Code formatting
- Multiple themes (vs-dark, vs-light, etc.)
- Minimap, line numbers, and other IDE features

It's implemented in `client/src/pages/Session.jsx`:
```javascript
import Editor from '@monaco-editor/react';

<Editor
  height="100%"
  language={language}  // 'javascript' or 'python'
  value={code}
  onChange={handleCodeChange}
  theme="vs-dark"
  options={{
    minimap: { enabled: false },
    fontSize: 14,
    wordWrap: 'on',
    automaticLayout: true,
  }}
/>
```

The editor automatically handles syntax highlighting when you switch between languages using the dropdown selector.

---

## Additional Information

### Project Structure
```
coding-interview-platform/
├── package.json (root - for concurrently)
├── README.md
├── server/
│   ├── server.js
│   └── package.json
├── client/
│   ├── src/
│   │   ├── pages/
│   │   │   ├── Home.jsx
│   │   │   ├── Home.css
│   │   │   ├── Session.jsx
│   │   │   └── Session.css
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── index.css
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
└── tests/
    ├── integration.test.js
    ├── jest.config.js
    └── package.json
```

### Installation Steps

1. **Install all dependencies:**
   ```bash
   cd D:\Ceren\Claude\coding-interview-platform
   npm run install:all
   ```

2. **Start the application:**
   ```bash
   npm run dev
   ```

3. **Run tests:**
   ```bash
   npm test
   ```

### Access the Application
- Frontend: http://localhost:5173
- Backend: http://localhost:3001

---

## Question 5: Code Execution with WASM

**Library used for compiling Python to WASM:**

**Pyodide** (version 0.24.1)

Pyodide is the scientific Python stack compiled to WebAssembly. It allows you to run Python code directly in the browser without a server.

### Implementation Details:

```javascript
import { loadPyodide } from 'pyodide';

// Load Pyodide (Python WASM runtime)
const pyodide = await loadPyodide({
  indexURL: 'https://cdn.jsdelivr.net/pyodide/v0.24.1/full/'
});

// Execute Python code
await pyodide.runPythonAsync(code);
```

### Features:
- ✅ Runs Python entirely in the browser (no server execution)
- ✅ Supports most Python standard library
- ✅ Can import scientific packages (numpy, pandas, etc.)
- ✅ Captures stdout/stderr output
- ✅ Secure - sandboxed in browser

### JavaScript Execution:
For JavaScript, we use native `eval()` with captured console output:
```javascript
const logs = [];
console.log = (...args) => logs.push(args.join(' '));
eval(code);
```

---

## Question 6: Containerization

**Base image used in Dockerfile:**

**node:20-alpine**

This is the official Node.js Docker image based on Alpine Linux (lightweight).

### Dockerfile Structure:
```dockerfile
FROM node:20-alpine

WORKDIR /app

# Install dependencies for both client and server
COPY package*.json ./
COPY server/package*.json ./server/
COPY client/package*.json ./client/

RUN npm install
RUN cd server && npm install
RUN cd client && npm install

# Copy source code
COPY server ./server
COPY client ./client

# Build client
RUN cd client && npm run build

# Expose ports
EXPOSE 3001 5173

# Start application
CMD ["npm", "run", "dev"]
```

### Why node:20-alpine?
- **Lightweight**: Alpine Linux is ~5MB vs Ubuntu ~188MB
- **Secure**: Minimal attack surface
- **Official**: Maintained by Node.js team
- **LTS**: Node.js 20 is Long Term Support version

### Running with Docker:

**Build:**
```bash
docker build -t coding-interview-platform .
```

**Run:**
```bash
docker run -p 3001:3001 -p 5173:5173 coding-interview-platform
```

**Using Docker Compose:**
```bash
docker-compose up
```

---

## Question 7: Deployment

**Service used for deployment:**

**Render** (https://render.com)

### Why Render?

✅ **Free Tier**: Free web services with 750 hours/month  
✅ **Docker Support**: Native Docker deployment  
✅ **Auto-Deploy**: Automatic deploys from GitHub  
✅ **HTTPS**: Free SSL certificates  
✅ **WebSocket Support**: Works with Socket.IO  
✅ **Infrastructure as Code**: `render.yaml` configuration  
✅ **Simple**: No complex configuration needed  

### Deployment Steps:

1. **Push to GitHub:**
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin <your-repo-url>
git push -u origin main
```

2. **Deploy on Render:**
   - Go to https://render.com/dashboard
   - Click "New +" → "Web Service"
   - Connect your GitHub repository
   - Render auto-detects the Dockerfile
   - Click "Create Web Service"

3. **Access your app:**
   - Your app will be live at: `https://your-app-name.onrender.com`

### Alternative Deployment Options:

I've also created deployment guides for:
- **Railway** (`deployment/RAILWAY.md`) - Great Docker support, $5/month free credit
- **Heroku** (`deployment/HEROKU.md`) - Popular PaaS platform

All deployment configurations are included in the project!

---

## Complete Feature List

✅ Real-time collaborative code editing  
✅ WebSocket-based synchronization  
✅ Session link sharing  
✅ Monaco Editor with syntax highlighting  
✅ JavaScript execution in browser  
✅ Python execution via Pyodide (WASM)  
✅ User presence indicators  
✅ Integration tests  
✅ Docker containerization  
✅ Production deployment setup  

---
