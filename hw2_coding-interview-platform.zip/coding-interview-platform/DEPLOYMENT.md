# Deployment Guide

This guide covers deploying the Coding Interview Platform to various cloud services.

## Quick Deployment Summary

**Recommended for homework:** Use **Render** or **Railway** as they offer free tiers and easy deployment.

## Option 1: Render (Recommended for Free Tier)

Render provides free hosting for web services with automatic HTTPS.

### Steps:

1. **Prepare your repository:**
   - Push your code to GitHub
   - Ensure `Dockerfile` is in the root directory

2. **Deploy on Render:**
   - Go to https://render.com
   - Sign up/Login with GitHub
   - Click "New +" → "Web Service"
   - Connect your GitHub repository
   - Configure:
     - **Name:** coding-interview-platform
     - **Environment:** Docker
     - **Instance Type:** Free
   - Click "Create Web Service"

3. **Configuration:**
   Render will automatically detect your Dockerfile and deploy.

4. **Access your app:**
   Your app will be available at: `https://your-app-name.onrender.com`

### Notes:
- Free tier sleeps after 15 minutes of inactivity
- First request may take 30-60 seconds to wake up
- Automatic HTTPS included

## Option 2: Railway

Railway offers excellent free tier with easy deployment.

### Steps:

1. **Prepare your repository:**
   - Push code to GitHub
   - Ensure `Dockerfile` exists

2. **Deploy on Railway:**
   - Go to https://railway.app
   - Sign up with GitHub
   - Click "New Project"
   - Select "Deploy from GitHub repo"
   - Choose your repository
   - Railway auto-detects Docker and deploys

3. **Configuration:**
   - Railway automatically assigns a domain
   - No additional configuration needed

4. **Access your app:**
   Click on the deployment to get your URL

### Notes:
- $5/month free credit
- Auto-sleeps when inactive
- Easy GitHub integration

## Option 3: Heroku

Classic platform with good free tier alternatives.

### Steps:

1. **Install Heroku CLI:**
   ```bash
   # Windows
   Download from https://devcenter.heroku.com/articles/heroku-cli

   # Mac
   brew tap heroku/brew && brew install heroku

   # Linux
   curl https://cli-assets.heroku.com/install.sh | sh
   ```

2. **Login to Heroku:**
   ```bash
   heroku login
   ```

3. **Create Heroku app:**
   ```bash
   heroku create your-app-name
   ```

4. **Deploy:**
   ```bash
   git push heroku main
   ```

5. **Open your app:**
   ```bash
   heroku open
   ```

### Notes:
- Free tier has been discontinued, but eco dynos are cheap ($5/month)
- Automatic deployments from GitHub available

## Option 4: Vercel (Frontend) + Backend Separate

Deploy frontend and backend separately for optimal performance.

### Frontend on Vercel:

1. **Deploy client to Vercel:**
   - Go to https://vercel.com
   - Import your GitHub repository
   - Root Directory: `client`
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Deploy

### Backend Options:
- Deploy backend to Render/Railway/Heroku
- Update frontend API URL to point to backend URL

## Option 5: Docker Container Services

### AWS ECS (Elastic Container Service):

1. **Build and push to ECR:**
   ```bash
   aws ecr create-repository --repository-name coding-interview-platform
   docker build -t coding-interview-platform .
   docker tag coding-interview-platform:latest YOUR_ECR_URI:latest
   docker push YOUR_ECR_URI:latest
   ```

2. **Create ECS Task Definition and Service:**
   - Use AWS Console or CLI
   - Configure task with your image
   - Set up load balancer

### Google Cloud Run:

1. **Build and deploy:**
   ```bash
   gcloud builds submit --tag gcr.io/PROJECT_ID/coding-interview-platform
   gcloud run deploy coding-interview-platform \
     --image gcr.io/PROJECT_ID/coding-interview-platform \
     --platform managed \
     --allow-unauthenticated
   ```

## Option 6: DigitalOcean App Platform

1. **Create App:**
   - Go to DigitalOcean App Platform
   - Connect GitHub repository
   - Select Dockerfile deployment
   - Configure resources
   - Deploy

## Environment Variables

For production deployment, you may need to set:

```bash
NODE_ENV=production
PORT=3001
```

## Post-Deployment Checklist

- [ ] Test session creation
- [ ] Test real-time code synchronization
- [ ] Test code execution (JavaScript and Python)
- [ ] Verify WebSocket connections work
- [ ] Check HTTPS is enabled
- [ ] Test with multiple users

## Troubleshooting

### WebSocket Connection Issues
If WebSocket fails in production:
- Ensure your hosting platform supports WebSocket
- Check CORS settings in `server.js`
- Verify SSL/TLS is properly configured

### Ports Not Accessible
- Check if hosting platform allows custom ports
- Some platforms only expose port 80/443
- Update `server.js` to use `process.env.PORT`

### Build Failures
- Check Docker logs: `docker logs <container-id>`
- Verify all dependencies are in package.json
- Ensure Dockerfile commands succeed locally

## Cost Comparison

| Platform | Free Tier | Sleeps? | Ease | Best For |
|----------|-----------|---------|------|----------|
| Render | Yes | Yes | ⭐⭐⭐⭐⭐ | Homework/Demo |
| Railway | $5 credit | Yes | ⭐⭐⭐⭐⭐ | Quick Deploy |
| Heroku | No* | No | ⭐⭐⭐⭐ | Production |
| Vercel | Yes | No | ⭐⭐⭐⭐ | Frontend |
| Cloud Run | $300 credit | Yes | ⭐⭐⭐ | Scalable Apps |

*Heroku requires eco dynos ($5/month minimum)

## Recommended Deployment for Homework

**Use Render:**
1. Push code to GitHub
2. Create new Web Service on Render
3. Connect repository
4. Deploy (automatic)
5. Share the Render URL

**Why Render?**
- Free tier available
- Automatic HTTPS
- Docker support
- Zero configuration
- Perfect for homework submissions

## Example Deployment URLs

After deployment, your URLs will look like:
- Render: `https://coding-interview-platform.onrender.com`
- Railway: `https://coding-interview-platform.up.railway.app`
- Heroku: `https://coding-interview-platform.herokuapp.com`

Share this URL in your homework submission!
