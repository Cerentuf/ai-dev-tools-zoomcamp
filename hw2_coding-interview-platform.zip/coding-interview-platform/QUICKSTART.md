# 🚀 QUICK START GUIDE

## Prerequisites
- ✅ Node.js installed (v18 or higher)
- ✅ npm installed

## Step-by-Step Setup

### 1️⃣ Navigate to Project Directory
```bash
cd D:\Ceren\Claude\coding-interview-platform
```

### 2️⃣ Install All Dependencies
```bash
# Install root dependencies (concurrently)
npm install

# Install server dependencies
cd server
npm install

# Install client dependencies
cd ../client
npm install

# Install test dependencies
cd ../tests
npm install

# Go back to root
cd ..
```

**OR use the shortcut:**
```bash
npm run install:all
```

### 3️⃣ Start the Application
```bash
npm run dev
```

This will start both:
- 🔧 Server on http://localhost:3001
- 💻 Client on http://localhost:5173

### 4️⃣ Access the App
Open your browser and go to:
```
http://localhost:5173
```

### 5️⃣ Test the App
1. Click "Create New Session"
2. You'll be redirected to a session page
3. Copy the URL and share it with others
4. Try editing code - all connected users see changes in real-time!
5. Select Python or JavaScript from the dropdown
6. Click "Run Code" to execute

---

## Running Tests

Make sure the server is running first, then in a new terminal:

```bash
cd tests
npm test
```

---

## Using Docker

### Option 1: Docker Build & Run
```bash
docker build -t coding-interview-platform .
docker run -p 3001:3001 -p 5173:5173 coding-interview-platform
```

### Option 2: Docker Compose
```bash
docker-compose up
```

Then access: http://localhost:5173

---

## Deploying to Render

### Step 1: Create GitHub Repository
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

### Step 2: Deploy on Render
1. Go to https://render.com
2. Sign up / Log in
3. Click "New +" → "Web Service"
4. Connect your GitHub account
5. Select your repository
6. Render will detect the Dockerfile automatically
7. Click "Create Web Service"
8. Wait for deployment (5-10 minutes)
9. Your app will be live! 🎉

---

## Troubleshooting

### Port Already in Use
If you see "Port 3001 is already in use":
```bash
# Windows
netstat -ano | findstr :3001
taskkill /PID <PID_NUMBER> /F

# Mac/Linux
lsof -ti:3001 | xargs kill -9
```

### Dependencies Not Installing
```bash
# Clear npm cache
npm cache clean --force

# Delete node_modules and reinstall
rm -rf node_modules package-lock.json
npm install
```

### Socket Connection Failed
Make sure both server and client are running:
- Server should be on port 3001
- Client should be on port 5173

---

## What You Can Do

✅ Create multiple interview sessions  
✅ Share session links with candidates  
✅ Collaborate in real-time  
✅ Execute Python code (via Pyodide/WASM)  
✅ Execute JavaScript code  
✅ See how many users are connected  
✅ Switch between programming languages  

---

## Next Steps

1. ✅ Test the application locally
2. ✅ Run the integration tests
3. ✅ Try running with Docker
4. ✅ Deploy to Render
5. ✅ Share your deployed URL!

---

**Need help? Check the detailed README.md or HOMEWORK_ANSWERS.md!**
