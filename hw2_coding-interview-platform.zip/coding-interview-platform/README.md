# Coding Interview Platform

A real-time collaborative coding interview platform built with React, Express.js, and Socket.IO.

## Features

- ✨ Create shareable interview session links
- 👥 Real-time collaborative code editing
- 🎨 Syntax highlighting for JavaScript and Python (Monaco Editor)
- 🔄 Live updates for all connected users
- ▶️ Code execution in browser (WASM-based)
- 🐍 Python execution via Pyodide (WASM)
- 🟨 JavaScript execution with captured console output
- 🐳 Docker containerization
- ☁️ Ready for cloud deployment

## Tech Stack

### Frontend
- React 18
- Vite
- Monaco Editor (VS Code editor component)
- Socket.IO Client
- React Router
- Pyodide (Python WASM runtime)

### Backend
- Express.js
- Socket.IO
- Node.js

## Prerequisites

- Node.js (v18 or higher)
- npm or yarn

## Installation

### 1. Install Server Dependencies

```bash
cd server
npm install
```

### 2. Install Client Dependencies

```bash
cd client
npm install
```

### 3. Install Test Dependencies

```bash
cd tests
npm install
```

## Running the Application

### Option 1: Run Server and Client Separately

**Terminal 1 - Start the server:**
```bash
cd server
npm run dev
```

**Terminal 2 - Start the client:**
```bash
cd client
npm run dev
```

The server will run on `http://localhost:3001`
The client will run on `http://localhost:5173`

### Option 2: Run Both Concurrently (Coming in Question 3)

```bash
npm run dev
```

## Running Tests

Make sure the server is running first, then:

```bash
cd tests
npm test
```

## Usage

1. Open `http://localhost:5173` in your browser
2. Click "Create New Session" to start a new interview
3. Copy the session link and share it with candidates
4. All users can edit code simultaneously with real-time updates
5. Select programming language (JavaScript or Python)
6. Click "Run Code" to execute code in the browser

## Project Structure

```
coding-interview-platform/
├── server/
│   ├── server.js          # Express + Socket.IO server
│   └── package.json
├── client/
│   ├── src/
│   │   ├── pages/
│   │   │   ├── Home.jsx   # Landing page
│   │   │   └── Session.jsx # Coding session page
│   │   ├── App.jsx
│   │   └── main.jsx
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
└── tests/
    ├── integration.test.js # Integration tests
    ├── jest.config.js
    └── package.json
```

## API Endpoints

### POST /api/session
Creates a new coding session
- Returns: `{ sessionId: string }`

### GET /api/session/:id
Retrieves session information
- Returns: `{ id, code, language, users }`

## WebSocket Events

### Client to Server
- `join-session` - Join a coding session
- `code-change` - Broadcast code changes
- `language-change` - Change programming language

### Server to Client
- `code-update` - Receive code updates
- `language-update` - Receive language changes
- `user-joined` - Notification when user joins
- `user-left` - Notification when user leaves

## Development

### Server Development
```bash
cd server
npm run dev  # Uses nodemon for auto-restart
```

### Client Development
```bash
cd client
npm run dev  # Vite hot module replacement
```

## Building for Production

### Build Client
```bash
cd client
npm run build
```

### Preview Production Build
```bash
cd client
npm run preview
```

## Docker Deployment

### Build Docker Image
```bash
docker build -t coding-interview-platform .
```

### Run with Docker
```bash
docker run -p 3001:3001 -p 5173:5173 coding-interview-platform
```

### Run with Docker Compose
```bash
docker-compose up
```

Access the application at `http://localhost:5173`

## Cloud Deployment

### Render (Recommended)
1. Push your code to GitHub
2. Go to https://render.com/dashboard
3. Click "New +" → "Web Service"
4. Connect your GitHub repository
5. Render will auto-detect the Dockerfile
6. Click "Create Web Service"

Your app will be live at: `https://your-app-name.onrender.com`

### Other Deployment Options
See detailed guides in the `deployment/` folder:
- **Railway**: `deployment/RAILWAY.md`
- **Heroku**: `deployment/HEROKU.md`

## Troubleshooting

### Port Already in Use
If port 3001 or 5173 is already in use, you can change them:
- Server: Edit `PORT` in `server/server.js`
- Client: Edit `server.port` in `client/vite.config.js`

### Socket Connection Issues
Make sure the server URL in client matches your server location:
- Check `socketRef.current = io('http://localhost:3001')` in `Session.jsx`
- Check CORS settings in `server.js`

## License

MIT
