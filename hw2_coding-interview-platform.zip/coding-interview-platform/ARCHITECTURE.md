# System Architecture

## High-Level Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                          CLIENT SIDE                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────┐         ┌──────────────┐                    │
│  │   Browser 1  │         │   Browser 2  │                    │
│  │              │         │              │                    │
│  │  ┌────────┐  │         │  ┌────────┐  │                    │
│  │  │ React  │  │         │  │ React  │  │                    │
│  │  │  App   │  │         │  │  App   │  │                    │
│  │  └────┬───┘  │         │  └────┬───┘  │                    │
│  │       │      │         │       │      │                    │
│  │  ┌────▼───────────┐    │  ┌────▼───────────┐               │
│  │  │ Monaco Editor  │    │  │ Monaco Editor  │               │
│  │  │ (Syntax       │    │  │ (Syntax       │               │
│  │  │ Highlighting) │    │  │ Highlighting) │               │
│  │  └────────────────┘    │  └────────────────┘               │
│  │                        │                                    │
│  │  ┌─────────────────┐   │  ┌─────────────────┐              │
│  │  │ Code Executor   │   │  │ Code Executor   │              │
│  │  │ - JavaScript    │   │  │ - JavaScript    │              │
│  │  │ - Pyodide(WASM) │   │  │ - Pyodide(WASM) │              │
│  │  └─────────────────┘   │  └─────────────────┘              │
│  │                        │                                    │
│  └────────┬───────────────┘  └────────┬───────────────────────┘
│           │                           │                         │
│           │    WebSocket Connection   │                         │
│           └───────────┬───────────────┘                         │
│                       │                                         │
└───────────────────────┼─────────────────────────────────────────┘
                        │
                        │ HTTP/WebSocket
                        │
┌───────────────────────▼─────────────────────────────────────────┐
│                        SERVER SIDE                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│                   ┌─────────────────┐                          │
│                   │  Express Server │                          │
│                   │   (Port 3001)   │                          │
│                   └────────┬────────┘                          │
│                            │                                    │
│              ┌─────────────┴─────────────┐                     │
│              │                           │                     │
│         ┌────▼─────┐              ┌──────▼──────┐             │
│         │ REST API │              │  Socket.io  │             │
│         │          │              │  WebSocket  │             │
│         │  POST    │              │   Server    │             │
│         │  /api/   │              │             │             │
│         │ sessions │              │  Real-time  │             │
│         │          │              │  Events:    │             │
│         │  GET     │              │  - join     │             │
│         │  /api/   │              │  - code     │             │
│         │ sessions │              │  - language │             │
│         │  /:id    │              │  - users    │             │
│         └────┬─────┘              └──────┬──────┘             │
│              │                           │                     │
│              └─────────────┬─────────────┘                     │
│                            │                                    │
│                   ┌────────▼────────┐                          │
│                   │ Session Manager │                          │
│                   │  (In-Memory)    │                          │
│                   │                 │                          │
│                   │  Map<sessionId, │                          │
│                   │  {              │                          │
│                   │   code,         │                          │
│                   │   language,     │                          │
│                   │   users,        │                          │
│                   │   createdAt     │                          │
│                   │  }>             │                          │
│                   └─────────────────┘                          │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## Component Interaction Flow

### 1. Session Creation Flow
```
User (Browser)
     │
     ├─1─► Click "Create Session"
     │
     ├─2─► POST /api/sessions
     │
     ▼
Express Server
     │
     ├─3─► Generate UUID
     │
     ├─4─► Store in sessions Map
     │
     ├─5─► Return sessionId
     │
     ▼
Client
     │
     └─6─► Navigate to /session/:sessionId
```

### 2. Real-time Collaboration Flow
```
User A (Browser 1)          Server          User B (Browser 2)
     │                        │                      │
     ├─1─► join-session ──────┤                      │
     │                        ├─2─► initial-code ───►│
     │                        ├─3─► user-count ─────►│
     │                        │                      │
     ├─4─► Type code          │                      │
     │                        │                      │
     ├─5─► code-change ───────┤                      │
     │                        ├─6─► code-update ────►│
     │                        │                      │
     │                        │    ◄─7─ Type code ───┤
     │                        │                      │
     │                        │    ◄─8─ code-change ─┤
     │                        │                      │
     │    ◄─9─ code-update ───┤                      │
     │                        │                      │
```

### 3. Code Execution Flow
```
User Input
     │
     ├─1─► Click "Run Code"
     │
     ▼
Check Language
     │
     ├─── JavaScript ──┐
     │                 │
     ├─── Python ──────┤
     │                 │
     ▼                 ▼
JavaScript Path    Python Path
     │                 │
     ├─2─► eval()      ├─2─► Load Pyodide
     │                 │      (if not loaded)
     │                 │
     ├─3─► Capture     ├─3─► runPythonAsync()
     │     console.log │
     │                 ├─4─► Capture stdout
     │                 │
     └─4─► Display ────┴─5─► Display
           Output              Output
```

## Technology Stack Details

```
┌─────────────────────────────────────────────┐
│              FRONTEND STACK                 │
├─────────────────────────────────────────────┤
│ React 18         │ UI Framework             │
│ Vite             │ Build Tool               │
│ Monaco Editor    │ Code Editor              │
│ Socket.io Client │ WebSocket Client         │
│ React Router     │ Routing                  │
│ Pyodide 0.23.4   │ Python Runtime (WASM)    │
└─────────────────────────────────────────────┘

┌─────────────────────────────────────────────┐
│              BACKEND STACK                  │
├─────────────────────────────────────────────┤
│ Node.js 18       │ Runtime                  │
│ Express.js       │ Web Framework            │
│ Socket.io        │ WebSocket Server         │
│ UUID             │ Session ID Generation    │
│ CORS             │ Cross-Origin Support     │
└─────────────────────────────────────────────┘

┌─────────────────────────────────────────────┐
│              TESTING STACK                  │
├─────────────────────────────────────────────┤
│ Jest             │ Test Framework           │
│ Supertest        │ HTTP Testing             │
│ Socket.io Client │ WebSocket Testing        │
└─────────────────────────────────────────────┘

┌─────────────────────────────────────────────┐
│              DEVOPS STACK                   │
├─────────────────────────────────────────────┤
│ Docker           │ Containerization         │
│ Concurrently     │ Process Manager          │
│ Render/Railway   │ Deployment Platform      │
└─────────────────────────────────────────────┘
```

## Data Flow Diagram

```
┌──────────────────────────────────────────────────────────────┐
│                        DATA FLOW                             │
└──────────────────────────────────────────────────────────────┘

User Action
    │
    ├── Create Session ────► REST API ────► Generate UUID
    │                                        Store Session
    │                                        Return URL
    │
    ├── Join Session ──────► WebSocket ───► Validate Session
    │                                        Send Initial Code
    │                                        Update User Count
    │
    ├── Edit Code ─────────► WebSocket ───► Update Session
    │                                        Broadcast to All
    │                                        Update UI
    │
    ├── Change Language ───► WebSocket ───► Update Session
    │                                        Broadcast to All
    │                                        Update UI
    │
    └── Execute Code ──────► Browser ──────► JavaScript: eval()
                                             Python: Pyodide
                                             Display Output
```

## Security Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     SECURITY LAYERS                         │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────────────────────────────────────┐              │
│  │  CLIENT-SIDE CODE EXECUTION               │              │
│  │  (Sandboxed)                              │              │
│  │                                           │              │
│  │  JavaScript: Isolated eval() context     │              │
│  │  Python: WebAssembly sandbox (Pyodide)   │              │
│  │                                           │              │
│  │  ✓ No server-side execution              │              │
│  │  ✓ No file system access                 │              │
│  │  ✓ No network access (from code)         │              │
│  └──────────────────────────────────────────┘              │
│                                                             │
│  ┌──────────────────────────────────────────┐              │
│  │  WEBSOCKET SECURITY                       │              │
│  │                                           │              │
│  │  ✓ Session validation                    │              │
│  │  ✓ CORS configuration                    │              │
│  │  ✓ No authentication bypass              │              │
│  └──────────────────────────────────────────┘              │
│                                                             │
│  ┌──────────────────────────────────────────┐              │
│  │  SESSION MANAGEMENT                       │              │
│  │                                           │              │
│  │  ✓ UUID-based sessions                   │              │
│  │  ✓ In-memory storage (no persistence)    │              │
│  │  ✓ Session isolation                     │              │
│  └──────────────────────────────────────────┘              │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## Scalability Considerations

```
Current Implementation:
┌────────────────┐
│ Single Server  │
│ In-Memory      │
│ Sessions       │
└────────────────┘

Future Scaling Options:
┌─────────────────────────────────────────────────────┐
│                                                     │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐        │
│  │ Server 1 │  │ Server 2 │  │ Server N │        │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘        │
│       │             │             │                │
│       └─────────────┼─────────────┘                │
│                     │                              │
│              ┌──────▼──────┐                       │
│              │   Redis     │                       │
│              │  (Sessions) │                       │
│              └─────────────┘                       │
│                                                     │
│              ┌─────────────┐                       │
│              │  Database   │                       │
│              │ (Persistent)│                       │
│              └─────────────┘                       │
│                                                     │
└─────────────────────────────────────────────────────┘
```

## Performance Metrics

```
┌─────────────────────────────────────────────────────┐
│              PERFORMANCE TARGETS                    │
├─────────────────────────────────────────────────────┤
│                                                     │
│ Session Creation:        < 100ms                   │
│ WebSocket Latency:       < 50ms                    │
│ Code Sync Delay:         < 100ms                   │
│ JavaScript Execution:    < 10ms                    │
│ Python Execution:                                  │
│   - First Run:           3-5 seconds (Pyodide)     │
│   - Subsequent:          < 100ms                   │
│ Monaco Editor Load:      < 500ms                   │
│                                                     │
└─────────────────────────────────────────────────────┘
```

## File Structure Map

```
coding-interview-platform/
│
├── 📁 client/                    Frontend Application
│   ├── 📁 src/
│   │   ├── 📁 components/
│   │   │   ├── Home.jsx         Landing page
│   │   │   ├── Home.css
│   │   │   ├── CodeEditor.jsx   Main editor
│   │   │   └── CodeEditor.css
│   │   ├── App.jsx              Router setup
│   │   ├── main.jsx             Entry point
│   │   └── index.css            Global styles
│   ├── index.html               HTML template
│   ├── vite.config.js           Vite configuration
│   └── package.json             Dependencies
│
├── 📁 server/                    Backend Application
│   ├── server.js                Express + Socket.io
│   ├── server.test.js           Integration tests
│   ├── jest.config.js           Test configuration
│   └── package.json             Dependencies
│
├── 📄 Dockerfile                 Container definition
├── 📄 .dockerignore              Docker exclusions
├── 📄 .gitignore                 Git exclusions
├── 📄 package.json               Root package
│
├── 📚 README.md                  Main documentation
├── 📚 HOMEWORK_ANSWERS.md        Homework solutions
├── 📚 QUICKSTART.md              Quick setup guide
├── 📚 DEPLOYMENT.md              Deployment guide
├── 📚 SUBMISSION_CHECKLIST.md   Submission helper
└── 📚 ARCHITECTURE.md            This file
```

## API Reference Quick View

### REST Endpoints
```
POST   /api/sessions          Create new session
GET    /api/sessions/:id      Get session info
```

### WebSocket Events
```
CLIENT → SERVER:
  join-session      Join a coding session
  code-change       Broadcast code update
  language-change   Change programming language

SERVER → CLIENT:
  initial-code      Initial state on join
  code-update       Code from other users
  language-update   Language from other users
  user-count        Connected users count
  error             Error messages
```

---

This architecture document provides a complete overview of the system design, data flow, and technical implementation details.
