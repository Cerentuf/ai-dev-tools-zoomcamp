from django.test import TestCase, Client
from django.urls import reverse
from .models import TODO
from datetime import date

class TODOModelTest(TestCase):
    def test_create_todo(self):
        todo = TODO.objects.create(
            title="Test TODO",
            description="Test description",
            due_date=date.today()
        )
        self.assertEqual(todo.title, "Test TODO")
        self.assertFalse(todo.is_resolved)

    def test_todo_string_representation(self):
        todo = TODO.objects.create(title="Test TODO")
        self.assertEqual(str(todo), "Test TODO")

class TODOViewsTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.todo = TODO.objects.create(
            title="Test TODO",
            description="Test description"
        )

    def test_home_view(self):
        response = self.client.get(reverse('home'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Test TODO")

    def test_create_todo(self):
        response = self.client.post(reverse('create_todo'), {
            'title': 'New TODO',
            'description': 'New description',
            'due_date': '2024-12-31'
        })
        self.assertEqual(response.status_code, 302)
        self.assertTrue(TODO.objects.filter(title='New TODO').exists())

    def test_delete_todo(self):
        response = self.client.post(reverse('delete_todo', args=[self.todo.id]))
        self.assertEqual(response.status_code, 302)
        self.assertFalse(TODO.objects.filter(id=self.todo.id).exists())

    def test_toggle_resolved(self):
        response = self.client.post(reverse('toggle_resolved', args=[self.todo.id]))
        self.todo.refresh_from_db()
        self.assertTrue(self.todo.is_resolved)
